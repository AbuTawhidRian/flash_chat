package com.rian.flash_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
